"""
Date: 2020.04.06
Author: Justin

要点说明：
测试ChromeDriver
会弹出一个Chrome的窗口
"""

from selenium import webdriver

browser = webdriver.Chrome()

